
Video Mode 92
==============================================================================


This mode is a simple derivative of Video Mode 90.

It is fully compatible for 8 pixels tall tiles, so the Video Mode 90 generator
should be used with it.

Note that the interface prefixes are also "m90" to retain full compatibility.
