#ifndef __SPRITES_H
#define __SPRITES_H

#define SPRITE_CURSOR 0

#endif
