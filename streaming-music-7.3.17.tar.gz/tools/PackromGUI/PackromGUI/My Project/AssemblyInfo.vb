﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("PackromGUI")> 
<Assembly: AssemblyDescription("Packages Hex ROMs into Uze files for the Uzebox. Extracts programs from Uze files and creates Hex files")> 
<Assembly: AssemblyCompany("Basement Hobbies")> 
<Assembly: AssemblyProduct("PackromGUI")> 
<Assembly: AssemblyCopyright("Basement Hobbies 2012")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("008a9242-70e0-4f0b-9378-cbd0ef5ffbf6")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.3.5.0")> 
<Assembly: AssemblyFileVersion("0.0.0.1")> 
