PackRomGUI 
----------

PackRomGUI is a graphical tool to edit the metadata in .uze files. 
It is a VB.NET application, hence it requires Visual Studio Express 2012 to compile.
http://www.microsoft.com/visualstudio/eng/downloads#d-2012-express